<?php

$con = new mysqli("localhost", "root", "YOURPASSWORD", "belajar_php_bukuTamu", 3306);

?>