# Dasar - Dasar Login
Belajar PHP Native base on project dengan membuat Login, Logout dan Dashboard sederhana 

## Sofware yang saya pakai
- PHP         8.1.2-1ubuntu2.14 
- Mysql       8.0.34-0ubuntu0.22.04.1
- phpMyAdmin  8.0.34-0ubuntu0.22.04.1

## Note Selama Belajar:
- mysql_query, mysql_fetch_assoc, dan mysql_num_rows sudah tidak support pada php saya, sehingga saya menggunakan $con->[nama_method] sebagai gantinya
- 
